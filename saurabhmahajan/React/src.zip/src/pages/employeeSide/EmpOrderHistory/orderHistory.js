

const EmployeeOrderHistory = () => {

    return(
        <div className="container">History</div>
    )
}

export default EmployeeOrderHistory