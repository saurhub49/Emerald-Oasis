import Header1 from "../../../components/Header1/header1"

const BestSeller=()=>{
    return <div>
        <Header1></Header1>
    </div>
}

export default BestSeller