

const FAQ = () => {
    return (
        <div>
            <h1>FAQs</h1>
        </div>
    )
}

export default FAQ