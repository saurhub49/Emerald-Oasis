package com.app.entities.constants;

public enum OrderStatus {
	CART, PLACED, ONTHEWAY, DELIVERED, REPORTED
}
