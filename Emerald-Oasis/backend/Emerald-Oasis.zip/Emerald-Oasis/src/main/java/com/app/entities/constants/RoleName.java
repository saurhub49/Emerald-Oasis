package com.app.entities.constants;

public enum RoleName {
	MANAGER, EMPLOYEE, CUSTOMER
}
