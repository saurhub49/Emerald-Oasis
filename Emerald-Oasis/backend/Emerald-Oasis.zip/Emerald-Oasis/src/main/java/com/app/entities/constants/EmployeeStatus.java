package com.app.entities.constants;

public enum EmployeeStatus {
	PENDING, CONFIRMED, AVAILABLE, UNAVAILABLE, REVOKED
}
